# Unit 4 January 2024 — worked revision solution
Run `python Activity4_Development/games_club.py` from the desired output directory.
Activities contain PDFs and editable source files. Candidate details are omitted. The original resources are retained. No GitHub commits were made.
